package com.example.myapplication;


import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.content.ClipboardManager;
public class MainActivity extends AppCompatActivity {
    EditText editText;
    Button button;
    TextView textView;
    ClipboardManager clipboardManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = findViewById(R.id.button);
        editText = findViewById(R.id.editText);
        textView = findViewById(R.id.textView);
    }

    public void CopyText(View view) {
        String text = editText.getText().toString();
        if (!text.isEmpty()) {
            clipboardManager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData clipData = ClipData.newPlainText("key", text);
            clipboardManager.setPrimaryClip(clipData);

        }
    }

    public void PasteText(View view) {
        ClipData clipData = clipboardManager.getPrimaryClip();
        assert clipData != null;
        ClipData.Item item = clipData.getItemAt(0);
        textView.setText(item.getText().toString());

    }

    public void buttonClicked(View view) {
        CopyText(view);
        PasteText(view);

    }
}
